package com.fullstack.security.entity;

public enum Role {
    USER,
    ADMIN
}
